#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "listas.h"

listaDeProjetos* criaListaDeProjetos(void){
	return NULL;
}

listaDeProfessores* criaListaDeProfessores(void){
	return NULL;
}

listaDeAlunos*criaListaDeAlunos(void){
	return NULL;

}

listaDeProjetos* insereEmListaDeProjetos(listaDeProjetos* Lista, char *nomeProjeto, int anoInicio, 
											int mesFim, int anoFim, char *situacao, char *natureza, 
												char *descricao, char *responsavel, char *integrante1, char *integrante2){
	listaDeProjetos *Nodo = (listaDeProjetos*) malloc(sizeof(listaDeProjetos));
	Nodo->proximoProjeto = NULL;
	strcpy(Nodo->nomeProjeto, nomeProjeto);
	Nodo->anoInicio = anoInicio;
	Nodo->mesFim = mesFim;
	Nodo->anoFim = anoFim;
	strcpy(Nodo->responsavel, responsavel);
	strcpy(Nodo->integrante1, integrante1);
	strcpy(Nodo->integrante2, integrante2);

	if (Lista == NULL){
		Lista = Nodo;
	}else{ 
		Nodo->proximoProjeto = Lista->proximoProjeto;
		Lista->proximoProjeto = Nodo;
	}
	return Lista;
}

listaDeProfessores* insereEmListaDeProfessores(listaDeProfessores *Lista, char* nomeProfessor, char* nomeParaCitacao){
	listaDeProfessores *Nodo = (listaDeProfessores*) malloc(sizeof(listaDeProfessores));
	Nodo->proximoProfessor = NULL;
	strcpy(Nodo->nomeProfessor, nomeProfessor);
	strcpy(Nodo->nomeParaCitacao, nomeParaCitacao);

	if (Lista == NULL){
		Nodo->numDeProfessores = 1;
		Nodo->id = 0;

		return Nodo;
	}else{

		Lista->numDeProfessores++;
		Nodo->id = Lista->numDeProfessores - 1;

		int repeticaoDeProfessores = confereSeProfessorJaEstaNaLista(Lista, nomeProfessor);

		/* Se o valor retornado pela funcao "confereSeProfessorJaEstaNaLista" for 0 eh porque nao esta ainda,
			portanto, acrescenta o professor ah lista */

		if(repeticaoDeProfessores == 0){
			if (Lista == NULL){
				Lista = Nodo;
			}else{ 
				Nodo->proximoProfessor = Lista->proximoProfessor;
				Lista->proximoProfessor = Nodo;
			}
			return Lista;
		}else{
			return Lista;
		}
	}
}

int confereSeProfessorJaEstaNaLista(listaDeProfessores* Lista, char* nomeProfessor){

	if (strcmp(Lista->nomeProfessor, nomeProfessor))
		return 1;
	else
		if(Lista->proximoProfessor==NULL)
			return 0;
		else 
			confereSeProfessorJaEstaNaLista(Lista->proximoProfessor, nomeProfessor);
	return 0;
}

listaDeAlunos* insereEmListaDeAlunos(listaDeAlunos *Lista, char* nomeAluno, char* matricula, int tipo){
	listaDeAlunos *Nodo = (listaDeAlunos*) malloc(sizeof(listaDeAlunos));
	Nodo->proximoAluno = NULL;
	strcpy(Nodo->nomeAluno, nomeAluno);
	strcpy(Nodo->matricula, matricula);
	Nodo->tipo = tipo;

	if (Lista == NULL){
		Lista = Nodo;
	}else{ 
		Nodo->proximoAluno = Lista->proximoAluno;
		Lista->proximoAluno = Nodo;
	}
	return Lista;
}

int professorID(listaDeProfessores* lista, ValorVertice Nome){
	int i;

	if(strcmp(lista->nomeProfessor, Nome)==0) return lista->id;
	else i = professorID(lista->proximoProfessor, Nome);

	return i;
}

void idRetornaNome(ValorVertice nome, listaDeProfessores* lista, int id){

	if (id == lista->id) strcpy(nome, lista->nomeProfessor);
	else idRetornaNome(nome, lista->proximoProfessor, id);

}
