typedef struct listadocentes{
struct listadocentes*prox;
char nomedocente[100];
}Listadocentes;


typedef struct listadiscentes{
struct listadiscentes*prox;
char nomediscente[100];
}Listadiscentes;


typedef struct listadiscentesexternos{
struct listadiscentesexternos*prox;
char nomediscenteexterno[100];
}Listadiscentesexternos;


typedef struct listadeprojetos {	
	char responsavel[100];
	char nomeprojeto[100];
	int anodeinicio;
	int anofim;
	char situacao[100];
	char natureza[100];
	char descricao[100];
	Listadocentes*docentes;
	Listadiscentes*discentes;
	Listadiscentesexternos*discentesexternos;
	struct listadeprojetos*prox;	
}listadeprojetosfinal;


listadeprojetosfinal *crialistadeprojetosfinal(void);
