var annotated_dup =
[
    [ "cs_pitch", "structcs__pitch.html", "structcs__pitch" ],
    [ "MuError", "class_mu_error.html", "class_mu_error" ],
    [ "MuMaterial", "class_mu_material.html", "class_mu_material" ],
    [ "MuMIDIMessage", "struct_mu_m_i_d_i_message.html", "struct_mu_m_i_d_i_message" ],
    [ "MuNote", "class_mu_note.html", "class_mu_note" ],
    [ "MuParamBlock", "class_mu_param_block.html", "class_mu_param_block" ],
    [ "MuVoice", "class_mu_voice.html", "class_mu_voice" ]
];