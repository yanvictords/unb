var searchData=
[
  ['cs_5fpitch',['cs_pitch',['../structcs__pitch.html',1,'']]]
];
