var searchData=
[
  ['harmonicminorscale',['HarmonicMinorScale',['../class_mu_material.html#a4c4252d55b32f016d590b4693b3ce08e',1,'MuMaterial::HarmonicMinorScale(float dur)'],['../class_mu_material.html#a866150f5d07c4c52b2fc58b666e26594',1,'MuMaterial::HarmonicMinorScale(int voiceNumber, float dur)']]],
  ['highest_5fc',['HIGHEST_C',['../_mu_material_8h.html#aa04f3d0fa93008c3f4d91ee054a3aff6',1,'MuMaterial.h']]]
];
