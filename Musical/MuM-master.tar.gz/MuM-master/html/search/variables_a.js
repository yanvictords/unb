var searchData=
[
  ['num_5fof_5foctaves',['NUM_OF_OCTAVES',['../_mu_material_8h.html#a13803900442e3f6323b907b124e214ed',1,'MuMaterial.h']]],
  ['num_5fof_5fscale_5fdegrees',['NUM_OF_SCALE_DEGREES',['../_mu_material_8h.html#a0eaefe15c8d97c3869d44ce77bfe542c',1,'MuMaterial.h']]]
];
