var searchData=
[
  ['addfunctiontables',['AddFunctionTables',['../class_mu_material.html#a21daea2a9e402afe3b306b0103757937',1,'MuMaterial']]],
  ['addnote',['AddNote',['../class_mu_material.html#a11c894401033cdfc0525f00aaa751362',1,'MuMaterial::AddNote(MuNote inNote)'],['../class_mu_material.html#a047caf51eb5ef93be7b7d694ebbc30af',1,'MuMaterial::AddNote(int voiceNumber, MuNote inNote)'],['../class_mu_voice.html#a260f4df2b388be09aca884b87d901dab',1,'MuVoice::AddNote()']]],
  ['addparam',['AddParam',['../class_mu_param_block.html#a32377e3d56434d01e905df6b93d1556a',1,'MuParamBlock']]],
  ['addvoices',['AddVoices',['../class_mu_material.html#aa6eb0bb17652ce9d32aa62d38ab2d627',1,'MuMaterial']]],
  ['amp',['Amp',['../class_mu_note.html#a868b077e346011240a9a5a48134e8511',1,'MuNote']]],
  ['append',['Append',['../class_mu_material.html#a3b496ec0a7b21977a1c06a4b47291f53',1,'MuMaterial']]],
  ['augtriad',['AugTriad',['../class_mu_material.html#ac69b599bec41966f2defd8ab69a1b1a6',1,'MuMaterial::AugTriad(float dur)'],['../class_mu_material.html#a05d202b4a2fea44bbb2fcff6325c3454',1,'MuMaterial::AugTriad(int voiceNumber, float dur)']]],
  ['augtriadsplit',['AugTriadSplit',['../class_mu_material.html#ae58d6e9b294ecb8369e8c9eef4c11f6c',1,'MuMaterial']]]
];
