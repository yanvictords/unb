var searchData=
[
  ['removeblanknotes',['RemoveBlankNotes',['../class_mu_material.html#ac42bb3b6024436375e26c44a26efa1a5',1,'MuMaterial::RemoveBlankNotes()'],['../class_mu_voice.html#a8580e56587e20a26cb7ba745de433653',1,'MuVoice::RemoveBlankNotes()']]],
  ['removelastnote',['RemoveLastNote',['../class_mu_voice.html#a35ac6af770cb47cbe3bdf2f2919385e4',1,'MuVoice']]],
  ['removenote',['RemoveNote',['../class_mu_material.html#a4e9ffd09e6d048dad2fc1a4fffe47414',1,'MuMaterial::RemoveNote(long noteNumber)'],['../class_mu_material.html#ad204b915b7de78a628b1971b9bd3932a',1,'MuMaterial::RemoveNote(int voiceNumber, long noteNumber)'],['../class_mu_voice.html#a97fc77e0fb0055819b51260354918120',1,'MuVoice::RemoveNote()']]],
  ['removevoice',['RemoveVoice',['../class_mu_material.html#af4a92eda1f9056419c9e8f6f354a4922',1,'MuMaterial']]],
  ['retro',['Retro',['../class_mu_material.html#ac946bc4df527339e0689c4b239d131bd',1,'MuMaterial::Retro(void)'],['../class_mu_material.html#ab32e4eefe2f244ed9418f9784d6dfd2a',1,'MuMaterial::Retro(int voiceNumber)']]]
];
