var searchData=
[
  ['c_5fnat',['C_NAT',['../_mu_material_8h.html#a725ca4bf1a1dc9b69a8ce421c07cd64c',1,'MuMaterial.h']]],
  ['c_5fsharp',['C_SHARP',['../_mu_material_8h.html#aeb530d21594cef996094e3949af7ac82',1,'MuMaterial.h']]],
  ['chromaticscale',['ChromaticScale',['../class_mu_material.html#a94bc95d9c938d65cf143827781e920c1',1,'MuMaterial::ChromaticScale(float dur)'],['../class_mu_material.html#a81e57571122b27e134bd007ec626c7bb',1,'MuMaterial::ChromaticScale(int voiceNumber, float dur)']]],
  ['clear',['Clear',['../class_mu_material.html#a77c567d07e834bcbc8405180e7d66ac9',1,'MuMaterial::Clear()'],['../class_mu_note.html#a574683801104e24bd103a731ea971143',1,'MuNote::Clear()'],['../class_mu_param_block.html#ac3103a6f2a3f1a7276e243dcfb9749c5',1,'MuParamBlock::Clear()'],['../class_mu_voice.html#a74499fb7619052f976222f058da0653f',1,'MuVoice::Clear()']]],
  ['clearerror',['ClearError',['../class_mu_material.html#a26a59b304af0f12fcb6241010020ba0d',1,'MuMaterial']]],
  ['clearvoice',['ClearVoice',['../class_mu_material.html#a997be1029e10feb598fa4384647837a6',1,'MuMaterial']]],
  ['colapsepitch',['ColapsePitch',['../class_mu_material.html#a0883349910a69699e8695eea1f277842',1,'MuMaterial::ColapsePitch(void)'],['../class_mu_material.html#a3eabb7356a60d5a24b9808e2b9eeae85',1,'MuMaterial::ColapsePitch(int voiceNumber)'],['../class_mu_note.html#a1cb208afc1d9f564439144876bdaae16',1,'MuNote::ColapsePitch()']]],
  ['contains',['Contains',['../class_mu_material.html#a52c6cef0bb3ec2b86ffe4ea36923e1d5',1,'MuMaterial']]],
  ['contractinterval',['ContractInterval',['../class_mu_material.html#adf5c04a9b9f15706c343e363c40e9f28',1,'MuMaterial::ContractInterval(int halfSteps)'],['../class_mu_material.html#a66f03cd7811ce39ee39c0492210172b6',1,'MuMaterial::ContractInterval(int voiceNumber, int halfSteps)']]],
  ['createnotefromcsoundline',['CreateNoteFromCsoundLine',['../class_mu_material.html#ac1c180534a82607841111731f71fae3f',1,'MuMaterial']]],
  ['crescendo',['Crescendo',['../class_mu_material.html#a74389cb9f29feaa68d326b57f4c0749e',1,'MuMaterial']]],
  ['cs_5fpitch',['cs_pitch',['../structcs__pitch.html',1,'cs_pitch'],['../_mu_note_8h.html#ae4af620d0acaa93e95c90b0bc1c03355',1,'cs_pitch():&#160;MuNote.h']]],
  ['csoundtolocalpitch',['CsoundToLocalPitch',['../class_mu_material.html#a813c81314bfcce0e170ca4abfb079b97',1,'MuMaterial']]],
  ['cspitch',['CsPitch',['../class_mu_note.html#a413170a8b97b767694174bd7c9fed360',1,'MuNote']]],
  ['csstring',['CsString',['../class_mu_note.html#a30e0b05db72a791fd7f51cdec3cd7393',1,'MuNote']]],
  ['cyclepitch',['CyclePitch',['../class_mu_material.html#a7130dbbbdf6bdef6033eadd756e5e4ae',1,'MuMaterial::CyclePitch(int times)'],['../class_mu_material.html#a719bf6c622b625f2e3acbb0e5c74036c',1,'MuMaterial::CyclePitch(int voiceNumber, int times)']]],
  ['cyclerhythm',['CycleRhythm',['../class_mu_material.html#a4fdbf032f13e1d6cc3d3553cd39f0fe2',1,'MuMaterial::CycleRhythm(int times)'],['../class_mu_material.html#abacc98039f840a66b7c2a4ea19d85f1d',1,'MuMaterial::CycleRhythm(int voiceNumber, int times)']]]
];
