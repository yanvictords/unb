var searchData=
[
  ['init',['Init',['../class_mu_param_block.html#a76764699e62972b09538d70b0dd05ad5',1,'MuParamBlock']]],
  ['insertvoices',['InsertVoices',['../class_mu_material.html#ac876ac6d73e9b0f01221cebd5b97c84f',1,'MuMaterial']]],
  ['inside',['Inside',['../_mu_util_8cpp.html#a6831e0507034c72773c13c2b3472af1e',1,'Inside(short value, short *array, short n):&#160;MuUtil.cpp'],['../_mu_util_8h.html#a6831e0507034c72773c13c2b3472af1e',1,'Inside(short value, short *array, short n):&#160;MuUtil.cpp']]],
  ['instr',['Instr',['../class_mu_note.html#af716c20097b446377494bc7689e4567a',1,'MuNote']]],
  ['instrumentnumber',['InstrumentNumber',['../class_mu_voice.html#a2d072993ad303d60ec7652b0c177fe71',1,'MuVoice']]],
  ['invert',['Invert',['../class_mu_material.html#a1bda293393619222488fa5b0eadace3f',1,'MuMaterial::Invert(void)'],['../class_mu_material.html#af31f9bd256f464420193cb54068245f2',1,'MuMaterial::Invert(int voiceNumber)']]],
  ['isemptyvoice',['IsEmptyVoice',['../class_mu_material.html#ac58477b43ac12f708fea0f1c4473c537',1,'MuMaterial']]]
];
