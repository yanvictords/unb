var searchData=
[
  ['wholetonescale',['WholeToneScale',['../class_mu_material.html#a001c0f64153e497040ec2c184f9187d2',1,'MuMaterial::WholeToneScale(float dur)'],['../class_mu_material.html#a0b5d45c961f00812542273475501018b',1,'MuMaterial::WholeToneScale(int voiceNumber, float dur)']]]
];
