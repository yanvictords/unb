var searchData=
[
  ['transpose',['Transpose',['../class_mu_material.html#ac6dec5f6a665301e64183564a05a1e63',1,'MuMaterial::Transpose(short interval)'],['../class_mu_material.html#ab8053f882f9f27b6a68d4147c7ac9100',1,'MuMaterial::Transpose(int voiceNumber, short interval)'],['../class_mu_material.html#a9c8fb5f2fcd22e7fc400b5a721dcf1c9',1,'MuMaterial::Transpose(int voiceNumber, long noteNumber, short interval)'],['../class_mu_material.html#ab6356275e7c18e23a9f3f4b2d5ca95ec',1,'MuMaterial::Transpose(int voiceNumber, long startingNote, long endingNote, short interval)'],['../class_mu_voice.html#a36d8045ad97c9d0f0471d997daadbce8',1,'MuVoice::Transpose(short interval)'],['../class_mu_voice.html#a989f952d7fd1e70d62c28f2101053e09',1,'MuVoice::Transpose(long noteNumber, short interval)']]],
  ['trunc',['Trunc',['../class_mu_param_block.html#a3d73add971ad9cc675140cabc8d05f1f',1,'MuParamBlock']]]
];
