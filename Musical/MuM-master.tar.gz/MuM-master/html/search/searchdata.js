var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvw~",
  1: "cm",
  2: "mr",
  3: "abcdefghilmnoprstvw~",
  4: "abcdefghlmnopst",
  5: "cmu",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

