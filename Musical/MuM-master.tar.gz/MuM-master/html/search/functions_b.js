var searchData=
[
  ['next',['Next',['../class_mu_note.html#a260232f7669ce69ce8b188e911671336',1,'MuNote']]],
  ['num',['Num',['../class_mu_param_block.html#a9a89f48be6b92d9b46d481403f7cd012',1,'MuParamBlock']]],
  ['numberofnotes',['NumberOfNotes',['../class_mu_material.html#af6dfcf38b68168c3c7319cddd94ab797',1,'MuMaterial::NumberOfNotes(void)'],['../class_mu_material.html#a08a95f1dba46ca0a0f2561d172f8ac77',1,'MuMaterial::NumberOfNotes(int voiceNumber)'],['../class_mu_voice.html#ad01891b97d5f090cca3655f96066b7fc',1,'MuVoice::NumberOfNotes()']]],
  ['numberofvoices',['NumberOfVoices',['../class_mu_material.html#a22357b432c4d4d6cffaac1be1f192181',1,'MuMaterial']]]
];
