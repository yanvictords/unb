var searchData=
[
  ['majorscale',['MajorScale',['../class_mu_material.html#ae7c9cdfc080aa998b6452f79653d1e51',1,'MuMaterial::MajorScale(float dur)'],['../class_mu_material.html#a83ba786685fd901491b3381464463977',1,'MuMaterial::MajorScale(int voiceNumber, float dur)']]],
  ['majorseventhchord',['MajorSeventhChord',['../class_mu_material.html#abe9492e3c32f8b4e9855b9cdde2af376',1,'MuMaterial']]],
  ['majortriad',['MajorTriad',['../class_mu_material.html#a000736d54bdcf6605d5045580b4fd7cd',1,'MuMaterial::MajorTriad(float dur)'],['../class_mu_material.html#a0e106552d8a169b557e9726770abf270',1,'MuMaterial::MajorTriad(int voiceNumber, float dur)']]],
  ['majortriadsplit',['MajorTriadSplit',['../class_mu_material.html#afe39bd4034fdad233eb519064e5d37e1',1,'MuMaterial']]],
  ['melodicminorscale',['MelodicMinorScale',['../class_mu_material.html#a36857e2b3dde3df14d3278189267d35e',1,'MuMaterial::MelodicMinorScale(float dur)'],['../class_mu_material.html#ad3c0578b7f2d31b532615f850d487310',1,'MuMaterial::MelodicMinorScale(int voiceNumber, float dur)']]],
  ['message',['Message',['../class_mu_error.html#a4a7db23f3345a19a34c74823dd1890a0',1,'MuError']]],
  ['midioff',['MIDIOff',['../class_mu_note.html#a1ff7353bae0ab57932a6c42572b11181',1,'MuNote']]],
  ['midion',['MIDIOn',['../class_mu_note.html#a6a41ab4157818c1b9155c95bc7bfa849',1,'MuNote']]],
  ['minorscale',['MinorScale',['../class_mu_material.html#a0b48f859b4e715a8a2fa1d523ff563f3',1,'MuMaterial::MinorScale(float dur)'],['../class_mu_material.html#a1307c9ae4a19cea8a5f47bbc9a595845',1,'MuMaterial::MinorScale(int voiceNumber, float dur)']]],
  ['minortriad',['MinorTriad',['../class_mu_material.html#a035d67981062ab722c4bebb6c46d5671',1,'MuMaterial::MinorTriad(float dur)'],['../class_mu_material.html#ab6b8cdfc2954a7cfc01bc434e236b124',1,'MuMaterial::MinorTriad(int voiceNumber, float dur)']]],
  ['minortriadsplit',['MinorTriadSplit',['../class_mu_material.html#a7348f90a56ef807eac8da3bbec0ff2fb',1,'MuMaterial']]],
  ['mix',['Mix',['../class_mu_material.html#a46fcd9552adfa830db19e66c7ea7613f',1,'MuMaterial::Mix(const MuMaterial &amp;inMaterial)'],['../class_mu_material.html#a5820000fdf9fe765e218c9cf9e53ff5c',1,'MuMaterial::Mix(int voiceNumber, const MuMaterial &amp;inMaterial, int inVoice)']]],
  ['mixints',['MixInts',['../_mu_util_8cpp.html#a625f6ab6406880cdf6a3d8bfc592d555',1,'MixInts(int *array, int n):&#160;MuUtil.cpp'],['../_mu_util_8h.html#a8089834394c3d90669341656086f35b0',1,'MixInts(int *array, int size):&#160;MuUtil.cpp']]],
  ['move',['Move',['../class_mu_material.html#a4b62770943db1926ca1af4fec4a92974',1,'MuMaterial::Move(float timePoint)'],['../class_mu_material.html#ac3a0e7c704b2bcd4938ebf6a9778d3cd',1,'MuMaterial::Move(int voiceNumber, float timePoint)'],['../class_mu_voice.html#a0c1f30b5fb538fb45bf7c97bfb32f932',1,'MuVoice::Move()']]],
  ['muerror',['MuError',['../class_mu_error.html#a88500ed5e4e4fcf53af001960a0f23b8',1,'MuError::MuError(void)'],['../class_mu_error.html#a0b6f1d49fb1397276d061290f9096b40',1,'MuError::MuError(short errorCode)']]],
  ['muinit',['MuInit',['../_mu_util_8cpp.html#aed0e623f52f0c8c52e83b917c4fa7b63',1,'MuInit(void):&#160;MuUtil.cpp'],['../_mu_util_8h.html#aed0e623f52f0c8c52e83b917c4fa7b63',1,'MuInit(void):&#160;MuUtil.cpp']]],
  ['mumaterial',['MuMaterial',['../class_mu_material.html#ab3c409c4b722f402ee5048665f6935d3',1,'MuMaterial::MuMaterial(void)'],['../class_mu_material.html#a09dc43b9e76a5d3be5312750d016ff07',1,'MuMaterial::MuMaterial(const MuMaterial &amp;inMaterial)'],['../class_mu_material.html#a3e395bed86f9ae03fbcb94fb8d5aff41',1,'MuMaterial::MuMaterial(const MuMaterial &amp;inMaterial, int fromVoice)']]],
  ['munote',['MuNote',['../class_mu_note.html#a83c88fbd867d72f2a74e1581271f509a',1,'MuNote::MuNote(void)'],['../class_mu_note.html#adb7c208c2df49b16ece805a8ea82d489',1,'MuNote::MuNote(const MuNote &amp;inNote)']]],
  ['muparamblock',['MuParamBlock',['../class_mu_param_block.html#a4abb8cc602a4872546fcb30f4daa428d',1,'MuParamBlock::MuParamBlock(void)'],['../class_mu_param_block.html#a659d946f0627c5720fd975ead8f68c15',1,'MuParamBlock::MuParamBlock(const MuParamBlock &amp;inBlock)']]],
  ['muvoice',['MuVoice',['../class_mu_voice.html#adccd5760a6dfdb080e208620f5726e5e',1,'MuVoice::MuVoice(void)'],['../class_mu_voice.html#a2881ed1eafcb74b4e37a9638ab1aca4d',1,'MuVoice::MuVoice(const MuVoice &amp;inVoice)']]]
];
