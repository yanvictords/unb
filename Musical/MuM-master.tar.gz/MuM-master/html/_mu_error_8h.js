var _mu_error_8h =
[
    [ "MuError", "class_mu_error.html", "class_mu_error" ],
    [ "MuERROR_CANNOT_INIT", "_mu_error_8h.html#a976c0cd024b9463011461f2f7094ab03", null ],
    [ "MuERROR_COULDNT_INIT_MATERIAL", "_mu_error_8h.html#a3dd8ff36781ed35e9577beb60112e4f8", null ],
    [ "MuERROR_COULDNT_OPEN_INPUT_FILE", "_mu_error_8h.html#ab290ef3f9ee289f722733f6a13bd9747", null ],
    [ "MuERROR_COULDNT_OPEN_OUTPUT_FILE", "_mu_error_8h.html#a654d614bc1c98e7f299ef588c4d3735c", null ],
    [ "MuERROR_INSUF_MEM", "_mu_error_8h.html#ab7c8d293db794850c91409d42501e937", null ],
    [ "MuERROR_INVALID_NOTE_RANGE", "_mu_error_8h.html#a3c4809123ffb0a89747dcea284ea28b0", null ],
    [ "MuERROR_INVALID_PARAMBLOCK_SIZE", "_mu_error_8h.html#a65a70bb56d00a1199951f4117301d331", null ],
    [ "MuERROR_INVALID_PARAMETER", "_mu_error_8h.html#a02584508b9a53a3d15303d0f235376bf", null ],
    [ "MuERROR_INVALID_SCALE_DEGREE", "_mu_error_8h.html#ae3c842616d76bf02741e988554f3d99f", null ],
    [ "MuERROR_INVALID_VOICE_NUMBER", "_mu_error_8h.html#ac80634b8890317573cc308e7412c4998", null ],
    [ "MuERROR_MATERIAL_IS_EMPTY", "_mu_error_8h.html#ab676373887a9cebad6b1ee87cf84ede2", null ],
    [ "MuERROR_NONE", "_mu_error_8h.html#aae156dd4a4259975d80938a87da017ef", null ],
    [ "MuERROR_NOTE_LIST_IS_EMPTY", "_mu_error_8h.html#ae95b14ba6a7b358e8ad9e6e19a2aea6b", null ],
    [ "MuERROR_NOTE_NOT_FOUND", "_mu_error_8h.html#a0072230480739cb2e2a17fcced9abea7", null ],
    [ "MuERROR_PARAM_BLOCK_NOT_INITIALIZED", "_mu_error_8h.html#a4ae42cbdfeb403ed35cd2f3a3e8dfd30", null ]
];