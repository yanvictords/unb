var struct_mu_m_i_d_i_message =
[
    [ "data1", "struct_mu_m_i_d_i_message.html#a338026c6455c6a244f15d4db81d706f1", null ],
    [ "data2", "struct_mu_m_i_d_i_message.html#a5bb497c05dee7fde545681185611ca4f", null ],
    [ "status", "struct_mu_m_i_d_i_message.html#ab50acb598f271fc92408a139f62cb77d", null ],
    [ "time", "struct_mu_m_i_d_i_message.html#a40afece9e3e264c6cf43e8be66663e5e", null ]
];