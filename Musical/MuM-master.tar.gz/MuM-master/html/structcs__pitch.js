var structcs__pitch =
[
    [ "octave", "structcs__pitch.html#abb6d7ed017a0784a342bc01859f7426e", null ],
    [ "pitch", "structcs__pitch.html#a7735f559bff026e5dbcfd406379a0a84", null ]
];