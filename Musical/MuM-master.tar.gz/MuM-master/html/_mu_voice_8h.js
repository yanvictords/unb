var _mu_voice_8h =
[
    [ "MuVoice", "class_mu_voice.html", "class_mu_voice" ],
    [ "FIRST_NOTE_INDEX", "_mu_voice_8h.html#afda38c8dfbcdc50630701536213365c8", null ],
    [ "SORT_FIELD_AMP", "_mu_voice_8h.html#ae5a6890524bef436cd7020756f90c44e", null ],
    [ "SORT_FIELD_DUR", "_mu_voice_8h.html#af809e184d765c67f3d7155f95811f3d2", null ],
    [ "SORT_FIELD_INSTR", "_mu_voice_8h.html#ae6f7337668c68d56a7b33a4035650b12", null ],
    [ "SORT_FIELD_PITCH", "_mu_voice_8h.html#ae4416386aa990d5269090638f5e6d838", null ],
    [ "SORT_FIELD_START", "_mu_voice_8h.html#a3f25a3731c6dc07ee9c3b5a909cf2296", null ]
];