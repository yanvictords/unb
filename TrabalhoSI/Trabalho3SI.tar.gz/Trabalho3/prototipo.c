#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*-------- Funcao sobre ------*/
void sobre(){
	system("clear||cls");
	FILE *seta1;
	seta1 = fopen("mesas.txt", "r+");
	char dados[100][3];

	printf("\n------------------- Sobre nos -------------------\n");
	fscanf(seta1, "\n%[^\n]s", dados[0]);
	printf("\n|%s", dados[0]);
	fscanf(seta1, "\n%[^\n]s", dados[1]);
	printf("\n|Fone: %s\n", dados[1]);
	fscanf(seta1, "\n%[^\n]s", dados[2]);
	printf("|Endereco: %s\n", dados[2]);
	fclose(seta1);
	printf("\n-------------------------------------------------\n");
	printf("\nPara voltar pressione uma <enter>...");
	getchar();
	getchar();
}
/*------- FIM OPCAO SOBRE ------*/

void menu(char restaurante[]){
system("clear||cls");
printf("\n------------------- Restaurante %s -------------------\n\n", restaurante);
printf("1. Reservar uma mesa\n");
	printf("2. Sobre nos\n");
	printf("3. Sair\n");
	printf("Opcao:");
}

int main(){
char restaurante[100], lixo[100], nome[100];
int interface, x=0, id, dia, mes, mesa, count=0, month, day, qtd, i, nmesa, rg, k;
system("clear||cls");
printf("------INTERFACE-------\n|1. Cliente\n|2. Setor Gerenciador do Atendimento\n-----------------------\nOpcao:");
scanf("%d", &interface);
while((interface>2)||(interface<1)){
	printf("Opcao invalida. Por favor, digite novamente:");
	scanf("%d", &interface);
}
if(interface==1){
while(x!=3){
	FILE *seta;
	seta = fopen("mesas.txt", "r+");
	fscanf(seta, "%[^\n]\n", restaurante);
	count=0;
	menu(restaurante); /*menu principal*/

	scanf("%d", &x);
	while((x>3)||(x<1)){
		printf("Opcao invalida. Por favor, digite novamente:");
		scanf("%d", &x);
	}

	if(x==1){
		system("clear||cls");
		printf("*** SGRO | %s***\n\n", restaurante);
		printf("Pesquisar por mesas disponiveis:\n");
		printf("|Dia:");
		scanf("%d", &day);
		while((day>31)||(day<1)){
			printf("Dia invalido. Por favor, digite novamente:");
			scanf("%d", &day);
		}
		printf("|Mes:");
		scanf("%d", &month);
		while((month>12)||(month<1)){
			printf("Mes invalido. Por favor, digite novamente:");
			scanf("%d", &month);
		}		

		system("clear||cls");
		printf("*** SGRO | %s***\n\n", restaurante);
		fscanf(seta, "%[^\n]\n", lixo);
		fscanf(seta, "%[^\n]\n", lixo);
		fscanf(seta, "%s %s %d %[^\n]\n", lixo, lixo, &qtd, lixo); /* Pega a quantidade de mesas */
		fscanf(seta, "%[^\n]\n", lixo);
		printf("Mesas disponiveis:\n");
		int disp[qtd];
		for(k=0;k<qtd;k++)
			disp[k]=0;
		while(!feof(seta)){
			fscanf(seta, "%d	%d	%d	%d	%[^\n]\n", &id, &dia, &mes, &mesa, lixo); 

			if((month==mes)&&(day==dia)){ /*Mesa reservada nesta dada */
				count++;
				disp[mesa-1]=1;
			}
		}

		
		if(count==qtd){ printf("0\n");
			printf("...Mesas indisponiveis para esta data...\n\n");
			printf("\nPara voltar pressione uma <enter>...");
			getchar(); getchar();
		}else{
			for(k=0;k<qtd;k++){
				if(disp[k]==0)
					printf("|Mesa |%d|\n", k+1);
			}
			
			printf("\nReservar uma mesa?\n");
			printf("1.Sim\n");
			printf("2.Nao\n");
			printf("Opcao:");
			scanf("%d", &i);
			while((i>2)||(i<1)){
				printf("Opcao invalida. Tente novamente:");
				scanf("%d", &i);
			}
			if(i==1){
				printf("Digite seu primeiro nome:");
				scanf("%s", nome);
				printf("RG(id):");
				scanf("%d", &rg);
				printf("Numero da mesa:");
				scanf("%d", &nmesa);
				while((disp[nmesa-1]==1)||(nmesa>qtd)||(nmesa<1)){
					printf("Mesa indisponivel. Por favor, digite uma mesa disponivel:");
					scanf("%d", &nmesa);
				}
				FILE *seta1;
				seta1=fopen("mesas.txt", "a");
				fprintf(seta1, "%d	%d	%d	%d	%s\n", rg, day, month, nmesa, nome);
				printf("Reserva efetuada com sucesso!\n\n");
				printf("...Pressione <Enter> para gerar o recibo...");
				getchar();
				getchar();
				system("clear||cls");
				printf("-------------------------------------------------\n");
				printf("|**RECIBO DE RESERVA**\n|\n");
				printf("|Nome: %s\n|RG: %d\n|\n|--Reserva--\n|%s |Mesa|: %d |Data|: %d/%d\n", nome, rg, restaurante, nmesa, day, month);
				printf("-------------------------------------------------\n");

				seta1=fopen("recibo.txt", "w+");
				fprintf(seta1,"-------------------------------------------------\n");
				fprintf(seta1,"|**RECIBO DE RESERVA**\n|\n");
				fprintf(seta1,"|Nome: %s\n|RG: %d\n|\n|--Reserva--\n|%s |Mesa|: %d |Data|: %d/%d\n", nome, rg, restaurante, nmesa, day, month);
				fprintf(seta1,"-------------------------------------------------\n");
				printf("\n Um recibo.txt foi gerado com sucesso!\n");
				printf("\nPara voltar pressione <Enter>...\n");
				getchar(); 
				
			}
			
		}

	}
	if(x==2)	
		sobre();
}



}else{
	char nomec[100], forma[20];
	int rgc, flag=0, valor, q=1;
	while(q!=3){
	system("clear||cls");
	printf("------------------- SGRO -------------------\n\n");
	printf("|1. Ver reservas\n|2. Consultar Recibo\n|3.Sair\nOpcao:");
	scanf("%d", &q);
	while((q<1)||(q>3)){
		printf("Opcao invalida. Por favor, digite novamente:");
		scanf("%d", &q);	
	}

	if(q==1){ 
		system("clear||cls");
		FILE *seta2;
		seta2 = fopen("mesas.txt", "r+");
		fscanf(seta2, "%[^\n]\n", lixo);
		fscanf(seta2, "%[^\n]\n", lixo);
		fscanf(seta2, "%[^\n]\n", lixo);
		fscanf(seta2, "%[^\n]\n", lixo);
		fscanf(seta2, "%[^\n]\n", lixo);
		printf("*** RESERVAS REGISTRADAS ***\n");
		while(!feof(seta2)){
			fscanf(seta2, "%d	%d	%d	%d	%[^\n]\n", &id, &dia, &mes, &mesa, lixo);  
			printf("\n|Nome do Cliente: %s\n", lixo);
			printf("|RG: %d\n", id);
			printf("|Mesa: |%d|\n", mesa);
			printf("|Data: %d/%d\n", dia, mes);
		}
		printf("\nPressione <Enter> para voltar...");
		getchar();getchar();
	}
	
	if(q==2){
	system("clear||cls");
	printf("-------------- Consultar reserva ------------\n");
	printf("Pressione <Enter> para verificar o recibo do cliente...");
	getchar();
	getchar();
	FILE *seta1;
	seta1=fopen("recibo.txt", "r+");
	if(seta1==NULL){
	printf("\nNenhum recibo gerado!\n\n");	
	exit(1);	
	}
	fscanf(seta1, "%[^\n]\n", lixo);
	fscanf(seta1, "%[^\n]\n", lixo);
	fscanf(seta1, "%[^\n]\n", lixo);
	fscanf(seta1, "%s %[^\n]\n", lixo, nomec);
	fscanf(seta1, "%s %d", lixo, &rgc);

	FILE *seta;
	seta = fopen("mesas.txt", "r+");
	fscanf(seta, "%[^\n]\n", lixo);
	fscanf(seta, "%[^\n]\n", lixo);
	fscanf(seta, "%[^\n]\n", lixo);
	fscanf(seta, "%[^\n]\n", lixo);
	fscanf(seta, "%[^\n]\n", lixo);
	while(!feof(seta)){
		fscanf(seta, "%d	%d	%d	%d	%[^\n]\n", &id, &dia, &mes, &mesa, lixo); 
		if((rgc==id)&&(!strcmp(nomec,lixo))){  
			printf("\n**Reserva encontrada**\n");
			printf("\n|Nome do Cliente: %s\n", lixo);
			printf("|RG: %d\n", id);
			printf("|Mesa: |%d|\n", mesa);
			printf("|Data: %d/%d\n", dia, mes);
			flag=1;
		}
	}
	if(flag!=0){
		printf("\n...Pressione <Enter>...\n");
		getchar();
		system("clear||cls");
		printf("...Registrando o Pagamento do(a) Cliente %s...", lixo);
		getchar();
		printf("Forma de pagamento:");
		scanf("%s", forma);
		printf("Valor do pagamento:");
		scanf("%d", &valor);
		seta1=fopen("Relatorio.txt", "a");
		fprintf(seta1, "---------------------------------\n");
		fprintf(seta1, "|RG Cliente: %d\n", id);
		fprintf(seta1, "|Nome Cliente: %s\n", lixo);
		fprintf(seta1, "|Forma de pagamento: %s\n", forma);
		fprintf(seta1, "|Valor do pagamento: %d\n", valor);
		fprintf(seta1, "|DATA : %d/%d HORA: %s\n",dia, mes,__TIME__);
		fprintf(seta1, "---------------------------------\n");
		fprintf(seta1,"\n");
		printf("\nArquivo Relatorio.txt criado com sucesso!\n");
		printf("\nPressione <Enter> para voltar...\n");
		getchar();getchar();
		
	}
	if(flag==0)
		printf("\n**Reserva NAO encontrada!**\n");
		
	}
}


}

printf("\n...Fim de processo...\n");
return 0;
}
